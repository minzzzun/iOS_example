//
//  CustomViewExTests.swift
//  CustomViewExTests
//
//  Created by 김민준 on 10/27/24.
//

import Testing
@testable import CustomViewEx

struct CustomViewExTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
